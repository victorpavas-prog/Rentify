# Rentify - Servicios Web (Ejemplo)

Proyecto de ejemplo que implementa servicios web REST para una aplicación de alquiler de autos "Rentify".

## Contenido obligatorio (para la evidencia)
1. Archivos del proyecto: Código fuente completo y archivos de configuración (esta carpeta).
2. Documentación del repositorio: ver `DOCUMENTACION_REPOSITORIO.md`.
3. Nomenclatura del ZIP: `NOMBRE_APELLIDO_AA5_EV03.zip`

## Cómo ejecutar (local)
1. Crear un entorno virtual:
   python -m venv venv
   source venv/bin/activate   # o venv\Scripts\activate en Windows
2. Instalar dependencias:
   pip install -r requirements.txt
3. Ejecutar:
   python app.py
4. Probar endpoints (ejemplo):
   GET  http://localhost:5000/cars
   POST http://localhost:5000/customers  (json: {"name":"Nuevo"})
   POST http://localhost:5000/rentals    (json: {"car_id":1,"customer_id":1})

## Enlace al repositorio
Pegue aquí el enlace directo a su repositorio en GitHub (obligatorio) después de crear el repo.
Ejemplo: https://github.com/USUARIO/rentify.git

