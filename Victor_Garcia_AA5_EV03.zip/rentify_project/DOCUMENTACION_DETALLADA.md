# Documentación técnica - Servicios Web Rentify (Resumen)

## Endpoints principales
- GET /cars
- GET /cars/<id>
- POST /cars
- GET /customers
- POST /customers
- GET /rentals
- POST /rentals

## Modelo de datos (ejemplo en memoria)
- Car: id, make, model, year, available (bool)
- Customer: id, name, email
- Rental: id, car_id, customer_id, status

## Recomendaciones para el repositorio (evidencia)
1. Crear un repositorio en GitHub y subir todo el contenido.
2. Incluir un commit inicial con mensaje: "Evidencia EV03 - Rentify - Victor Garcia".
3. En `DOCUMENTACION_REPOSITORIO.md` pegar el enlace directo (URL) al repo.
4. Comprimir la carpeta raíz del proyecto con el nombre solicitado:
   Victor_Garcia_AA5_EV03.zip

## Notas
- Este proyecto es un ejemplo didáctico con datos en memoria. Para producción:
  - Añadir una base de datos (Postgres, MySQL).
  - Añadir autenticación y manejo de permisos.
  - Validaciones y manejo de errores detallado.
