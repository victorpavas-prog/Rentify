from flask import Flask, jsonify, request, abort

app = Flask(__name__)

# Datos en memoria (ejemplo)
cars = [
    {"id": 1, "make": "Toyota", "model": "Corolla", "year": 2020, "available": True},
    {"id": 2, "make": "Hyundai", "model": "Accent", "year": 2019, "available": True}
]

customers = [
    {"id": 1, "name": "Juan Perez", "email": "juan@example.com"}
]

rentals = []

# Endpoints básicos
@app.route('/cars', methods=['GET'])
def list_cars():
    return jsonify(cars)

@app.route('/cars/<int:car_id>', methods=['GET'])
def get_car(car_id):
    car = next((c for c in cars if c["id"] == car_id), None)
    if not car:
        abort(404)
    return jsonify(car)

@app.route('/cars', methods=['POST'])
def create_car():
    data = request.get_json()
    if not data or "make" not in data:
        abort(400)
    new_id = max([c["id"] for c in cars]) + 1 if cars else 1
    car = {"id": new_id, "make": data["make"], "model": data.get("model",""), "year": data.get("year",0), "available": True}
    cars.append(car)
    return jsonify(car), 201

@app.route('/rentals', methods=['GET'])
def list_rentals():
    return jsonify(rentals)

@app.route('/rentals', methods=['POST'])
def create_rental():
    data = request.get_json()
    if not data or "car_id" not in data or "customer_id" not in data:
        abort(400)
    car = next((c for c in cars if c["id"] == data["car_id"]), None)
    cust = next((u for u in customers if u["id"] == data["customer_id"]), None)
    if not car or not cust or not car["available"]:
        abort(400)
    rental_id = len(rentals) + 1
    rental = {"id": rental_id, "car_id": car["id"], "customer_id": cust["id"], "status": "active"}
    car["available"] = False
    rentals.append(rental)
    return jsonify(rental), 201

@app.route('/customers', methods=['GET'])
def list_customers():
    return jsonify(customers)

@app.route('/customers', methods=['POST'])
def create_customer():
    data = request.get_json()
    if not data or "name" not in data:
        abort(400)
    new_id = max([u["id"] for u in customers]) + 1 if customers else 1
    cust = {"id": new_id, "name": data["name"], "email": data.get("email","")}
    customers.append(cust)
    return jsonify(cust), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
