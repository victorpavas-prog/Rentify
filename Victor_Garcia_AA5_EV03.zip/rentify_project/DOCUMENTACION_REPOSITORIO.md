# Documentación del Repositorio - Rentify

Coloque en este documento el enlace directo al repositorio (URL pública de GitHub) y una breve guía de uso.

- Enlace directo al repositorio: **PEGE AQUI TU ENLACE**
- Branch principal: main
- Instrucciones de despliegue y pruebas: ver README.md
